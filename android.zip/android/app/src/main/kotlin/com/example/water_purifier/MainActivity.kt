package com.example.water_purifier

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
